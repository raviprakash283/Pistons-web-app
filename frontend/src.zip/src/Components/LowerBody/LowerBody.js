import React from 'react'
import "./Lowerbody.css"

import im from "../../assets/Frame 31.png"
import krk from "../../assets/krk.png"
import fmn from "../../assets/Frame 9.png"

const A = () => {
  return (
    <div className='ii'>

         <img src={im}/>

    </div>
  )
}

const B= () => {
    <div className='ib'>

    <img src={krk}/>
    <img src={fmn}/>

</div>

}


const LowerBody = () => {
    // Define a breakpoint (e.g., 768px) to switch between desktop and mobile navigation
    const breakpoint = 768;
    const isMobile = window.innerWidth <= breakpoint;
  
    return isMobile ? <B /> : <A/>;
  };
  

export default LowerBody