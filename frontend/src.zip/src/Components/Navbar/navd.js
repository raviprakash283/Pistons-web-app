


import React, { useState } from 'react'
import { Link } from 'react-scroll'

import './navd.css'; // Import your CSS file
import srch from"../../assets/search.jpeg"
import cart from"../../assets/cart.png"


  
  // const op = () => {
  //   const breakpoint = 768;
  //   const isMobile = window.innerWidth <= breakpoint;
    
  //   return isMobile ?  (<div></div>): (<div className='option'>
  //   <div> <a href="#">NEW</a> </div>
  //   <div> <a href="#">BRANDS</a> </div>
  //   <div>  <a href="#">COLLECTIONS</a></div>
  //   <div> <a href="#">ACCESSORIES</a> </div>
  //   <div> <Link to="hero"  spy={true} smooth={true} offset={-100} duration={500}> ABOUT</Link> </div>
 

  // </div>) ;
  // }
  



function Navbar() {
  const [isSearchOpen, setSearchOpen] = useState(false);
 
  
    // 

  const toggleSearch = () => {
    setSearchOpen(!isSearchOpen);
  };

  return (
    <div className="navbar">
      <div className="logo">PISTONS</div>
         
         <div className='option'>
          <div> <a href="#">NEW</a> </div>
          <div> <a href="#">BRANDS</a> </div>
          <div>  <a href="#">COLLECTIONS</a></div>
          <div> <a href="#">ACCESSORIES</a> </div>
          <div> <Link to="hero"  spy={true} smooth={true} offset={-100} duration={500}> ABOUT</Link> </div>
       

        </div> 
         
        
        <div>
      <div className={`search ${isSearchOpen ? 'open' : ''}`}>
        <input type="text" placeholder="" />
        <button onClick={toggleSearch}>Search</button>
      </div>
           
         

      <button onClick={toggleSearch} className="search-button">
        
         <img className='kk' src={srch}/>
         {/* <img className='kk' src={cart}/> */}
         
      </button>



     

      </div>
       
      
      
    </div>
  );
}

export default Navbar;

