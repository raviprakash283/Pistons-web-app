import React, { useState } from "react";
import "./navm.css"; // Import your CSS file
import srch from"../../assets/search.jpeg"

function Navm() {

    const [menuVisible, setMenuVisible] = useState(false);
    const [isSearchOpen, setSearchOpen] = useState(false);

  const toggleSearch = () => {
    setSearchOpen(!isSearchOpen);
  };

  const toggleMenu = () => {
    setMenuVisible(!menuVisible);
  };

  return (
    <div className="topnav">
      <a href="#home" className="active">
        Logo
      </a>

      <div id="myLinks" style={{ display: menuVisible ? "block" : "none" }}>
        <a href="#news">News</a>
        <a href="#contact">Contact</a>
        <a href="#about">About</a>
      </div>

      <div className={`search ${isSearchOpen ? 'open' : ''}`}>
        <input type="text" placeholder="" />
        <button onClick={toggleSearch}>Search</button>
      </div>

      
      <button onClick={toggleSearch} className="search-button">
        
         <img className='kk' src={srch}/>
        
         
      </button>

      <a href="javascript:void(0);" className="icon" onClick={toggleMenu}>
        {/* <i className="fa fa-bars"></i> */}
      </a>
    </div>
  );
    
}

export default Navm;
