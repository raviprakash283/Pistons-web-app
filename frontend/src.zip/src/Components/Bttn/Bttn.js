import React from 'react'
import "./Bttn.css"

const  Bttn= () => {
  return (
    <div>

<div className="fixed-button">
      <button>Feedback</button>
      </div>
    </div>
  )
}

export default Bttn; 